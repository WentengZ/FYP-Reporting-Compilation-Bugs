#include"try2.h"
#include<stdio.h>

int main(){
    printf("h");
    printf("e");
    printf("l");
    printf("l");
    printf("o");
    try2();
}
