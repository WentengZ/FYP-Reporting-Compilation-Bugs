#include<stdio.h>
void try2(){
    printf(" ");
    printf("w");
    printf("o");
    printf("r");
    printf("l");
    printf("d");
}
